// /api

var logger = {
    
    //set time
    time: 30000,

    //set log types
    types: [
        'error',
        'info',
        'warn'
    ],
    
    //logs array
    logs: [],
    
    //sent logs
    sent: [],
    
    //filter function
    filter: function(list, callback){
        var output = [];
        for(var l in list){
            if( callback(list[l], l) ){
                output.push(list[l]);
            }
        };
        return output;
    },
    
    //set logs as sent
    setSentLogs: function(logs){
        var timestamps = [];
        //get timestamps of each log
        this.filter(logs, function(log){
             timestamps.push(log.timestamp)
        });
        //for each
        for(var l in this.logs){
            if(
                timestamps.indexOf(this.logs[l].timestamp) !=-1 
            ) {
                this.logs[l].sent = true;
            }
        }
    },
    
    //get logs
    getLogs: function(type){
        return this.filter(this.logs, function( log ){
            return (log.type == type)
        });
    },
    
    //send logs
    sendLog: function(type){
        
        //set this
        var this_ = this;
        
        //check for types
        type = (type) ? type: false;
        
        //set  default
        var logs = (type) ? this.getLogs(type) : this.logs;
        
        //filter logs by ones not sent
        var filteredLogs = this.filter(logs, function(log){
            return (log.sent == false)
        });
        
        //check if we have any unsent logs
        if( filteredLogs.length > 0 ){
            //send data to server
            jQuery.post('/api',filteredLogs, 
            //success
            function( data ){
                console.log('Logged succesfully: ', data);
                //set logs as sent
                this_.setSentLogs(logs);
            },
            //error
            function( data ){
                console.error('Did not log: ', data);
            });
        }
    },
    
    //test for errors
    isError: function(callback){
        var error = false;
        try{
            callback();
        } catch(e){
            error = true;
            this.setLog('error', e);
        }
        return error
    }
    
    //set log
    setLog: function(type, message){
        this.logs.push(
            {
                type: type,
                sent: false,
                message: e,
                timestamp: Date.now()
            }    
        );
    }
};

window.setInterval(function(){
    logger.sendLog();
},logger.time)
    
    